(function(){
  function safe(tag){return document.createElement(tag);}
  function addMeta(name, content){
    if(!content) return;
    var m = safe('meta');
    if(name.indexOf(':')>-1){ m.setAttribute('property', name); }
    else{ m.setAttribute('name', name); }
    m.setAttribute('content', content);
    document.head.appendChild(m);
  }
  function addLink(rel, href, attrs){
    if(!href) return;
    var l = safe('link'); l.rel = rel; l.href = href;
    if(attrs){ for (var k in attrs){ l.setAttribute(k, attrs[k]); } }
    document.head.appendChild(l);
  }
  function addLD(json){
    var s = safe('script'); s.type = 'application/ld+json';
    s.text = JSON.stringify(json);
    document.head.appendChild(s);
  }
  function apply(cfg){
    // SEO
    if(cfg.seo){
      if(cfg.seo.robots) addMeta('robots', cfg.seo.robots);
      if(cfg.seo.canonical){
        addLink('canonical', location.href.split('#')[0]);
      }
      if(Array.isArray(cfg.seo.hreflang)){
        cfg.seo.hreflang.forEach(function(h){
          addLink('alternate', h.href, {hreflang: h.lang});
        });
      }
    }
    // Social
    if(cfg.social && cfg.social.og){
      var og = cfg.social.og;
      Object.keys(og).forEach(function(k){ addMeta('og:'+k, og[k]); });
    }
    if(cfg.social && cfg.social.twitter){
      var tw = cfg.social.twitter;
      Object.keys(tw).forEach(function(k){ addMeta('twitter:'+k, tw[k]); });
    }
    // Structured data
    if(Array.isArray(cfg.structured_data)){
      cfg.structured_data.forEach(addLD);
    }
    // Performance
    if(cfg.performance){
      (cfg.performance.preconnect||[]).forEach(function(h){ addLink('preconnect', h, {crossorigin:''}); });
      (cfg.performance.preload||[]).forEach(function(p){ addLink('preload', p.href, {as:p.as, type:p.type||'', crossorigin:p.crossorigin||''}); });
      if(cfg.performance.critical_css_url){ addLink('stylesheet', cfg.performance.critical_css_url); }
    }
    // Security (meta fallbacks only—real CSP should be server-side)
    if(cfg.security){
      if(cfg.security.referrer_policy){ addMeta('referrer', cfg.security.referrer_policy); }
      // CSP via meta: limited; provided here only for basic cases.
      if(cfg.security.csp){
        var s = safe('meta'); s.httpEquiv = "Content-Security-Policy"; s.content = cfg.security.csp; document.head.appendChild(s);
      }
    }
  }
  function load(){
    var url = window.HEADCORE_CONFIG_URL;
    if(!url) return;
    fetch(url, {credentials:'omit'}).then(function(r){ return r.json(); }).then(apply).catch(function(){});
  }
  if(document.readyState === 'loading'){ document.addEventListener('DOMContentLoaded', load); }
  else { load(); }
})();