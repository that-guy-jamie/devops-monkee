<?php
if (!defined('ABSPATH')) { exit; }

class Headcore_Validator {
    public static function validate($cfg){
        // Minimal checks for MVP
        if (!isset($cfg['site'])) return ['ok'=>false,'error'=>'Missing site'];
        if (!isset($cfg['version'])) return ['ok'=>false,'error'=>'Missing version'];
        // TODO: schema validation using justinrainbow/json-schema or similar
        // TODO: verify signature (Ed25519)
        return ['ok'=>true];
    }
}
