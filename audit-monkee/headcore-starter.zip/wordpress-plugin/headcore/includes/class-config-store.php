<?php
if (!defined('ABSPATH')) { exit; }

class Headcore_Config_Store {
    public static function save($cfg, $raw_json){
        update_option(HEADCORE_OPTION_CONFIG, $cfg, false);
        $versions = get_option(HEADCORE_OPTION_VERSIONS, []);
        array_unshift($versions, [
            'saved_at' => current_time('mysql', 1),
            'config' => $cfg
        ]);
        $versions = array_slice($versions, 0, 10);
        update_option(HEADCORE_OPTION_VERSIONS, $versions, false);
    }

    public static function current(){
        $cfg = get_option(HEADCORE_OPTION_CONFIG, null);
        return $cfg ? $cfg : null;
    }

    public static function versions(){
        return get_option(HEADCORE_OPTION_VERSIONS, []);
    }
}
