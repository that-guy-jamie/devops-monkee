# UX Flow

1. **Select Audit**: SEO / Design / Tech Stack / All
2. **Target**: paste root domain; select Contact from GHL
3. **Run**: job queued; progress bar updates
4. **Deliver**:
   - Contact **Note** with executive summary + score
   - **Custom Fields** with key metrics
   - Optional **PDF** report (deep detail)
