from typing import Dict, Any
def detect_stack(url: str) -> Dict[str, Any]:
    # TODO: implement real fingerprinting
    return {"cms": "WordPress", "cdn": "Cloudflare", "analytics": ["GA4"]}
