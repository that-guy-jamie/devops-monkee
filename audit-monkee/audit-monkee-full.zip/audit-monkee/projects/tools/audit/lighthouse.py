from typing import Dict, Any
def run_lighthouse(url: str) -> Dict[str, Any]:
    # TODO: integrate real Lighthouse/PSI
    # Placeholder scores
    return {
        "performance": 78,
        "accessibility": 92,
        "best_practices": 89,
        "seo": 88,
        "cwv": {"LCP": 2.5, "INP": 180, "CLS": 0.06}
    }
