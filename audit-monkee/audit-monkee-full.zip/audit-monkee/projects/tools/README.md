# Audit Monkee — API & Worker (FastAPI + Celery)

## Quick start (dev, SQLite + local Redis)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
make initdb
make dev  # http://localhost:8000
# in another terminal
make worker
```

### Create an audit
```bash
curl -X POST http://localhost:8000/api/audits -H 'Content-Type: application/json' \  -d '{"contactId":"abc123","locationId":"loc_1","url":"https://example.com","types":["seo","design","stack"]}'
```

### Get audit
```bash
curl http://localhost:8000/api/audits/<AUDIT_ID>
```

### Headcore config
Set `HEADCORE_PRIVATE_KEY` in `.env` (base64url Ed25519), then:
```bash
curl -X POST http://localhost:8000/api/audits/<AUDIT_ID>/headcore
```

> PDF output is a simple `.txt` placeholder to keep deps light. Replace with real PDF rendering later.
