from typing import Dict, Any, Optional

class GHLClient:
    def __init__(self, token: Optional[str] = None):
        self.token = token

    def create_contact_note(self, contact_id: str, body: str) -> None:
        # TODO: implement call to GHL contacts/{id}/notes
        print(f"[GHL] Note to {contact_id}: {body[:60]}...")

    def update_contact_fields(self, contact_id: str, fields: Dict[str, Any]) -> None:
        # TODO: implement patch to contact custom fields
        print(f"[GHL] Update fields for {contact_id}: {list(fields.keys())}")

    def attach_pdf(self, contact_id: str, pdf_path: str) -> None:
        # TODO: upload PDF to file field or conversation with attachment
        print(f"[GHL] Attach PDF {pdf_path} to {contact_id}")
