import os
from datetime import datetime

def generate_pdf(audit_id: str, summary: str, out_dir: str = "./reports") -> str:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{audit_id}.txt")
    # Minimal placeholder: write text file instead of a PDF to avoid heavy deps
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"Audit Report {audit_id}\nGenerated {datetime.utcnow().isoformat()}Z\n\n")
        f.write(summary or "No summary")
    return path
