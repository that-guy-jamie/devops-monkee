# Ed25519 signing helper for Headcore configs
# Usage:
#   python sign_config.py genkeys > keys.json
#   python sign_config.py sign --keys keys.json --in config.json --out signed.json

import json, sys, argparse, base64
from datetime import datetime
from nacl import signing

def b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip('=')

def b64url_decode(s: str) -> bytes:
    pad = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)

def deep_ksort(obj):
    if isinstance(obj, dict):
        return {k: deep_ksort(obj[k]) for k in sorted(obj.keys())}
    elif isinstance(obj, list):
        return [deep_ksort(x) for x in obj]
    else:
        return obj

def genkeys():
    sk = signing.SigningKey.generate()
    vk = sk.verify_key
    out = {
        "public_key": b64url(bytes(vk)),
        "secret_key": b64url(bytes(sk))
    }
    print(json.dumps(out, indent=2))

def sign(keys_path, in_path, out_path):
    with open(keys_path) as f:
        keys = json.load(f)
    sk = signing.SigningKey(b64url_decode(keys["secret_key"]))
    with open(in_path) as f:
        cfg = json.load(f)
    cfg = dict(cfg)  # copy
    cfg.pop("signature", None)
    cfg_sorted = deep_ksort(cfg)
    msg = json.dumps(cfg_sorted, separators=(',', ':'), ensure_ascii=False)
    sig = sk.sign(msg.encode()).signature
    cfg["signature"] = b64url(sig)
    with open(out_path or in_path, "w") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    print(f"Signed -> {out_path or in_path}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("genkeys")
    s = sub.add_parser("sign")
    s.add_argument("--keys", required=True)
    s.add_argument("--in", dest="inp", required=True)
    s.add_argument("--out", dest="outp", default=None)
    args = ap.parse_args()
    if args.cmd == "genkeys":
        genkeys()
    elif args.cmd == "sign":
        sign(args.keys, args.inp, args.outp)
    else:
        ap.print_help()
