# Headcore — Auto-apply `<head>` best practices (Add-on for Audit Monkee)

**Turn audits into improvements in one click.** Headcore takes Audit Monkee’s findings and safely injects SEO, social, structured data, and performance hints — directly into your site.

## What it does
- Adds/normalizes canonical, robots, hreflang.
- Fills OpenGraph + Twitter tags with safe defaults.
- Adds Organization/LocalBusiness schema (and more).
- Improves Core Web Vitals with preconnect/preload and optional critical CSS.
- Optional meta-level security headers (referrer policy, basic CSP).

## How it installs
- **WordPress plugin**: paste or fetch a signed JSON config from Audit Monkee.
- **GHL Sites / any builder**: drop-in snippet that fetches the config and injects tags.
- Signed configs (Ed25519) ensure integrity; domain binding prevents cross-site use. Rollback anytime.

## Why agencies love it
- **Instant wins** from an audit — visible changes in minutes.
- **Versioned & reversible** by design.
- **White-labeled reports** show before/after scores and applied actions.

## Plans
- Included in **Audit Monkee Pro** (core tags + schema).
- **Headcore Plus** ($19/site/mo): CWV preloads, critical CSS URL, scheduled re-apply, Slack alerts.

## Requirements
- Audit Monkee (for config generation) and site access to install either the WP plugin or head snippet.

## Support & Data
- No PII collected. Telemetry is opt-in and aggregate only (what actions were applied).
- Support: support@oneclickseo.com
