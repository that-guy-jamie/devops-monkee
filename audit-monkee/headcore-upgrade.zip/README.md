# Headcore — Starter Pack (with Ed25519, Rules Map, and Marketplace Copy)

This pack adds three things on top of the MVP:
1) **Ed25519 signature verification** in the WordPress plugin (uses PHP libsodium).
2) **Rules map** file to convert Audit Monkee findings → Headcore config actions.
3) **GHL Marketplace listing draft** you can paste into your app submission.

Contents:
- `wordpress-plugin/headcore/` — WP plugin with public-key setting + signature verification.
- `rules/headcore_rules.json` — findings → actions map.
- `schema/headcore.schema.json` — config contract (signature included).
- `examples/example-config.json` — signed example (placeholder signature).
- `server-tools/sign_config.py` — Python helper to generate keys and sign configs (Ed25519).
- `marketplace/listing.md` — draft description, features, pricing, and install notes.
