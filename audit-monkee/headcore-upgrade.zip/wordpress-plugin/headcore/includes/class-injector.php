<?php
if (!defined('ABSPATH')) { exit; }

class Headcore_Injector {
    private static function e($s){ return esc_attr($s); }
    private static function href($s){ return esc_url($s); }

    public static function output($cfg){
        // SEO
        if (!empty($cfg['seo'])){
            $seo = $cfg['seo'];
            if (!empty($seo['robots'])){
                echo '<meta name="robots" content="'.self::e($seo['robots']).'"/>'."\n";
            }
            if (!empty($seo['canonical'])){
                echo '<link rel="canonical" href="'.self::href(self::current_url()).'"/>'."\n";
            }
            if (!empty($seo['hreflang']) && is_array($seo['hreflang'])){
                foreach ($seo['hreflang'] as $h){
                    $lang = isset($h['lang']) ? $h['lang'] : '';
                    $href = isset($h['href']) ? $h['href'] : '';
                    if ($lang && $href){
                        echo '<link rel="alternate" hreflang="'.self::e($lang).'" href="'.self::href($href).'"/>'."\n";
                    }
                }
            }
        }

        // Social OG
        if (!empty($cfg['social']['og']) && is_array($cfg['social']['og'])){
            foreach ($cfg['social']['og'] as $k=>$v){
                echo '<meta property="og:'.self::e($k).'" content="'.self::e($v).'"/>'."\n";
            }
        }
        // Twitter
        if (!empty($cfg['social']['twitter']) && is_array($cfg['social']['twitter'])){
            foreach ($cfg['social']['twitter'] as $k=>$v){
                echo '<meta name="twitter:'.self::e($k).'" content="'.self::e($v).'"/>'."\n";
            }
        }

        // Structured data
        if (!empty($cfg['structured_data']) && is_array($cfg['structured_data'])){
            foreach ($cfg['structured_data'] as $obj){
                echo '<script type="application/ld+json">'.wp_json_encode($obj).'</script>'."\n";
            }
        }

        // Performance
        if (!empty($cfg['performance'])){
            $perf = $cfg['performance'];
            if (!empty($perf['preconnect']) && is_array($perf['preconnect'])){
                foreach ($perf['preconnect'] as $p){
                    echo '<link rel="preconnect" href="'.self::href($p).'" crossorigin />'."\n";
                }
            }
            if (!empty($perf['preload']) && is_array($perf['preload'])){
                foreach ($perf['preload'] as $p){
                    $href = isset($p['href']) ? $p['href'] : '';
                    $as = isset($p['as']) ? $p['as'] : '';
                    $type = isset($p['type']) ? $p['type'] : '';
                    $xo = isset($p['crossorigin']) ? $p['crossorigin'] : '';
                    if ($href && $as){
                        echo '<link rel="preload" href="'.self::href($href).'" as="'.self::e($as).'"';
                        if ($type) echo ' type="'.self::e($type).'"';
                        if ($xo) echo ' crossorigin="'.self::e($xo).'"';
                        echo ' />'."\n";
                    }
                }
            }
            if (!empty($perf['critical_css_url'])){
                echo '<link rel="stylesheet" href="'.self::href($perf['critical_css_url']).'"/>'."\n";
            }
        }

        // Security (meta fallbacks; real CSP/HSTS should be server-side)
        if (!empty($cfg['security'])){
            $sec = $cfg['security'];
            if (!empty($sec['referrer_policy'])){
                echo '<meta name="referrer" content="'.self::e($sec['referrer_policy']).'"/>'."\n";
            }
            if (!empty($sec['csp'])){
                echo '<meta http-equiv="Content-Security-Policy" content="'.self::e($sec['csp']).'"/>'."\n";
            }
        }
    }

    private static function current_url(){
        $scheme = is_ssl() ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $uri = strtok($_SERVER['REQUEST_URI'], '#');
        return $scheme . '://' . $host . $uri;
    }
}
