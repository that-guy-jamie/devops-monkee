<?php
if (!defined('ABSPATH')) { exit; }

class Headcore_Validator {
    public static function validate($cfg, $pubkey_b64url){
        if (!isset($cfg['site'])) return ['ok'=>false,'error'=>'Missing site'];
        if (!isset($cfg['version'])) return ['ok'=>false,'error'=>'Missing version'];
        if (!isset($cfg['signature'])) return ['ok'=>false,'error'=>'Missing signature'];
        if (!function_exists('sodium_base642bin')) {
            return ['ok'=>false,'error'=>'libsodium not available on this PHP install'];
        }
        if (!$pubkey_b64url) return ['ok'=>false,'error'=>'No public key configured'];

        // Make canonical JSON by recursively ksorting arrays and removing signature
        $data = $cfg;
        unset($data['signature']);
        $data = self::deep_ksort($data);
        $json = wp_json_encode($data, JSON_UNESCAPED_SLASHES);

        // Decode public key and signature (base64url)
        try {
            $pubkey = sodium_base642bin($pubkey_b64url, SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
            $sig = sodium_base642bin($cfg['signature'], SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING);
        } catch (Exception $e) {
            return ['ok'=>false,'error'=>'Invalid base64url in key or signature'];
        }

        $ok = sodium_crypto_sign_verify_detached($sig, $json, $pubkey);
        if (!$ok) return ['ok'=>false,'error'=>'Signature verification failed'];

        return ['ok'=>true];
    }

    private static function deep_ksort($arr){
        if (is_array($arr)){
            // Distinguish associative vs sequential arrays
            $is_assoc = array_keys($arr) !== range(0, count($arr) - 1);
            if ($is_assoc) {
                ksort($arr, SORT_STRING);
                foreach ($arr as $k => $v) {
                    $arr[$k] = self::deep_ksort($v);
                }
            } else {
                // Sequential: sort each element if needed, keep order otherwise
                foreach ($arr as $i => $v) {
                    $arr[$i] = self::deep_ksort($v);
                }
            }
        }
        return $arr;
    }
}
