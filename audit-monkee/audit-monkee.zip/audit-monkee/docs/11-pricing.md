# Pricing & Packaging

- Starter $49 (5 audits/mo)
- Pro $99 (20 audits/mo)
- Scale $149 (50 audits/mo)
- Add-ons: schedule re-audit, white-label PDF, Slack alerts
