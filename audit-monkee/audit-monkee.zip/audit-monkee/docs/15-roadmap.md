# Roadmap

- v0.1: MVP audits + GHL write-backs
- v0.2: White-label PDF + scheduling
- v0.3: Multi-page crawls & sitemaps
- v0.4: Headcore one-click apply (WP + GHL Sites)
- v0.5: Slack alerts and team dashboard
