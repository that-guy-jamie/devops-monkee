# Audit Monkee — Enterprise Tool (skeleton)

Implement the API + worker here. See `/workorders/workorder-audit-monkey.md` for requirements.

Suggested layout:
- `api/` (FastAPI/Express app)
- `worker/` (Celery/BullMQ)
- `db/` (migrations)
- `Dockerfile`, `Makefile`, `requirements.txt` or `package.json`
