# GHL Custom Fields

Create these once per sub-account:

- `audit_monkee_score` (number)
- `audit_monkee_perf` (number)
- `audit_monkee_accessibility` (number)
- `audit_monkee_schema_found` (checkbox)
- `audit_monkee_stack` (long text)
- `audit_monkee_report` (file upload)
- `audit_monkee_last_run` (datetime)
