# Reporting & PDF

- Executive summary (score, key wins/risk)
- Section detail (SEO, Design, Tech Stack)
- CWV charts (LCP/INP/CLS)
- Attach to GHL Contact as PDF; store `report_url` for retrieval
