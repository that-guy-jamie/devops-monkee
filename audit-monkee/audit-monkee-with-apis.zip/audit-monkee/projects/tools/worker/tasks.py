import uuid, json
from celery import Celery
from datetime import datetime
from .util import SessionLocal
from ..api.models import Audit, AuditFinding
from ..audit.lighthouse import run_lighthouse
from ..audit.seo import run_seo_checks
from ..audit.tech import detect_stack
from ..api.pdf import generate_pdf
from ..api.ghclient import GHLClient

celery_app: Celery = None

def init_celery(celery: Celery):
    global celery_app
    celery_app = celery

@celery_app.task(name="audit.run")
def run_audit_task(audit_id: str):
    db = SessionLocal()
    try:
        audit = db.query(Audit).filter(Audit.id == audit_id).one()
        audit.status = "running"
        db.commit()

        lh = run_lighthouse(audit.url)
        seo = run_seo_checks(audit.url)
        tech = detect_stack(audit.url)

        audit.lighthouse_perf = lh.get("performance")
        audit.lighthouse_accessibility = lh.get("accessibility")
        audit.lighthouse_best_practices = lh.get("best_practices")
        audit.lighthouse_seo = lh.get("seo")
        audit.cwv_json = lh.get("cwv")
        audit.tech_stack_json = tech
        audit.overall_score = int(round(sum([audit.lighthouse_perf, audit.lighthouse_accessibility, audit.lighthouse_best_practices, audit.lighthouse_seo]) / 4))
        audit.summary = f"Overall score {audit.overall_score}. Perf {audit.lighthouse_perf}, Acc {audit.lighthouse_accessibility}, BP {audit.lighthouse_best_practices}, SEO {audit.lighthouse_seo}."
        db.commit()

        # Write PDF and simulate GHL write-back
        pdf_path = generate_pdf(audit.id, audit.summary)
        gh = GHLClient()
        gh.create_contact_note(audit.contact_id, audit.summary or "")
        gh.upsert_contact_custom_fields(audit.client_id or '', audit.contact_id, {
            "audit_monkee_score": audit.overall_score,
            "audit_monkee_perf": audit.lighthouse_perf,
            "audit_monkee_accessibility": audit.lighthouse_accessibility
        })
        gh.attach_pdf(audit.contact_id, pdf_path)

        audit.report_url = pdf_path
        audit.status = "done"
        db.commit()
    except Exception as e:
        audit = db.query(Audit).filter(Audit.id == audit_id).one_or_none()
        if audit:
            audit.status = "failed"
            audit.summary = f"Error: {e}"
            db.commit()
        raise
    finally:
        db.close()
